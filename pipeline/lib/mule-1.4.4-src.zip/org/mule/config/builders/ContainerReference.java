/*
 * $Id: ContainerReference.java 7963 2007-08-21 08:53:15Z dirk.olmes $
 * --------------------------------------------------------------------------------------
 * Copyright (c) MuleSource, Inc.  All rights reserved.  http://www.mulesource.com
 *
 * The software in this package is published under the terms of the CPAL v1.0
 * license, a copy of which has been included with this distribution in the
 * LICENSE.txt file.
 */

package org.mule.config.builders;

import org.mule.config.i18n.CoreMessages;
import org.mule.impl.container.ContainerKeyPair;
import org.mule.umo.manager.ContainerException;
import org.mule.umo.manager.UMOContainerContext;

import java.util.List;
import java.util.Map;

import org.apache.commons.beanutils.BeanUtils;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * <code>ContainerReference</code> maintains a container reference for the
 * MuleXmlConfigurationBuilder that gets wired once the configuration documents have
 * been loaded.
 */
public class ContainerReference
{
    /**
     * logger used by this class
     */
    protected static final Log logger = LogFactory.getLog(ContainerReference.class);

    private String propertyName;
    private String containerRef;
    private String container;
    private Object object;
    private boolean required;

    public ContainerReference(String propertyName,
                              String containerRef,
                              Object object,
                              boolean required,
                              String container)
    {
        this.propertyName = propertyName;
        this.containerRef = containerRef;
        this.container = container;
        this.object = object;
        this.required = required;
    }

    public void resolveReference(UMOContainerContext ctx) throws ContainerException
    {
        Object comp = ctx.getComponent(new ContainerKeyPair(container, containerRef, required));
        if (comp == null)
        {
            return;
        }

        try
        {
            if (object instanceof Map)
            {
                ((Map) object).put(propertyName, comp);
            }
            else if (object instanceof List)
            {
                ((List) object).add(comp);
            }
            else
            {
                BeanUtils.setProperty(object, propertyName, comp);
            }
        }
        catch (Exception e)
        {
            throw new ContainerException(
                CoreMessages.cannotSetPropertyOnObjectWithParamType(propertyName, 
                    object.getClass(), comp.getClass()), e);
        }
    }
}
