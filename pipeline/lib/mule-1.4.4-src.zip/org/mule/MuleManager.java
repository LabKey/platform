/*
 * $Id: MuleManager.java 10660 2008-02-01 11:57:38Z dirk.olmes $
 * --------------------------------------------------------------------------------------
 * Copyright (c) MuleSource, Inc.  All rights reserved.  http://www.mulesource.com
 *
 * The software in this package is published under the terms of the CPAL v1.0
 * license, a copy of which has been included with this distribution in the
 * LICENSE.txt file.
 */

package org.mule;

import org.mule.config.ConfigurationException;
import org.mule.config.MuleConfiguration;
import org.mule.config.MuleManifest;
import org.mule.config.MuleProperties;
import org.mule.config.ThreadingProfile;
import org.mule.config.i18n.CoreMessages;
import org.mule.impl.container.MultiContainerContext;
import org.mule.impl.internal.admin.MuleAdminAgent;
import org.mule.impl.internal.notifications.AdminNotification;
import org.mule.impl.internal.notifications.AdminNotificationListener;
import org.mule.impl.internal.notifications.ComponentNotification;
import org.mule.impl.internal.notifications.ComponentNotificationListener;
import org.mule.impl.internal.notifications.ConnectionNotification;
import org.mule.impl.internal.notifications.ConnectionNotificationListener;
import org.mule.impl.internal.notifications.CustomNotification;
import org.mule.impl.internal.notifications.CustomNotificationListener;
import org.mule.impl.internal.notifications.ExceptionNotification;
import org.mule.impl.internal.notifications.ExceptionNotificationListener;
import org.mule.impl.internal.notifications.ManagementNotification;
import org.mule.impl.internal.notifications.ManagementNotificationListener;
import org.mule.impl.internal.notifications.ManagerNotification;
import org.mule.impl.internal.notifications.ManagerNotificationListener;
import org.mule.impl.internal.notifications.MessageNotification;
import org.mule.impl.internal.notifications.MessageNotificationListener;
import org.mule.impl.internal.notifications.ModelNotification;
import org.mule.impl.internal.notifications.ModelNotificationListener;
import org.mule.impl.internal.notifications.NotificationException;
import org.mule.impl.internal.notifications.SecurityNotification;
import org.mule.impl.internal.notifications.SecurityNotificationListener;
import org.mule.impl.internal.notifications.ServerNotificationManager;
import org.mule.impl.internal.notifications.TransactionNotification;
import org.mule.impl.internal.notifications.TransactionNotificationListener;
import org.mule.impl.model.ModelFactory;
import org.mule.impl.model.ModelHelper;
import org.mule.impl.security.MuleSecurityManager;
import org.mule.impl.work.MuleWorkManager;
import org.mule.management.stats.AllStatistics;
import org.mule.umo.UMOException;
import org.mule.umo.UMOInterceptorStack;
import org.mule.umo.endpoint.UMOEndpoint;
import org.mule.umo.lifecycle.FatalException;
import org.mule.umo.lifecycle.InitialisationException;
import org.mule.umo.manager.UMOAgent;
import org.mule.umo.manager.UMOContainerContext;
import org.mule.umo.manager.UMOManager;
import org.mule.umo.manager.UMOServerNotification;
import org.mule.umo.manager.UMOServerNotificationListener;
import org.mule.umo.manager.UMOWorkManager;
import org.mule.umo.model.UMOModel;
import org.mule.umo.provider.UMOConnector;
import org.mule.umo.security.UMOSecurityManager;
import org.mule.umo.transformer.UMOTransformer;
import org.mule.util.CollectionUtils;
import org.mule.util.SpiUtils;
import org.mule.util.StringMessageUtils;
import org.mule.util.StringUtils;
import org.mule.util.UUID;
import org.mule.util.queue.QueueManager;
import org.mule.util.queue.QueuePersistenceStrategy;
import org.mule.util.queue.TransactionalQueueManager;

import java.net.InetAddress;
import java.net.UnknownHostException;
import java.nio.charset.Charset;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Iterator;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;

import javax.transaction.TransactionManager;
import javax.xml.parsers.SAXParserFactory;

import edu.emory.mathcs.backport.java.util.concurrent.atomic.AtomicBoolean;

import org.apache.commons.collections.MapUtils;
import org.apache.commons.collections.list.CursorableLinkedList;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;

/**
 * <code>MuleManager</code> maintains and provides services for a Mule instance.
 */
public class MuleManager implements UMOManager
{
    /**
     * singleton instance
     */
    private static UMOManager instance = null;

    /**
     * Default configuration
     */
    private static MuleConfiguration config = new MuleConfiguration();

    /**
     * Connectors registry
     */
    private Map connectors = new HashMap();

    /**
     * Endpoints registry
     * 
     * @deprecated endpoint-identifiers have been deprecated in favor of
     *             global-endpoints
     */
    private Map endpointIdentifiers = new HashMap();

    /**
     * Holds any application scoped environment properties set in the config
     */
    private Map applicationProps = new HashMap();

    /**
     * Holds any registered agents
     */
    private Map agents = new LinkedHashMap();

    /**
     * Holds a list of global endpoints accessible to any client code
     */
    private Map endpoints = new HashMap();

    /**
     * The model being used
     */
    private Map models = new LinkedHashMap();

    /**
     * the unique id for this manager
     */
    private String id = UUID.getUUID();

    /**
     * The transaction Manager to use for global transactions
     */
    private TransactionManager transactionManager = null;

    /**
     * Collection for transformers registered in this component
     */
    private Map transformers = new HashMap();

    /**
     * True once the Mule Manager is initialised
     */
    private AtomicBoolean initialised = new AtomicBoolean(false);

    /**
     * True while the Mule Manager is initialising
     */
    private AtomicBoolean initialising = new AtomicBoolean(false);

    /**
     * Determines of the MuleManager has been started
     */
    private AtomicBoolean started = new AtomicBoolean(false);

    /**
     * Determines in the manager is in the process of starting
     */
    private AtomicBoolean starting = new AtomicBoolean(false);

    /**
     * Determines in the manager is in the process of stopping.
     */
    private AtomicBoolean stopping = new AtomicBoolean(false);

    /**
     * Determines if the manager has been disposed
     */
    private AtomicBoolean disposed = new AtomicBoolean(false);

    /**
     * Maintains a reference to any interceptor stacks configured on the manager
     */
    private Map interceptorsMap = new HashMap();

    /**
     * the date in milliseconds from when the server was started
     */
    private long startDate = 0;

    /**
     * stats used for management
     */
    private AllStatistics stats = new AllStatistics();

    /**
     * Manages all Server event notificationManager
     */
    private ServerNotificationManager notificationManager = null;

    private MultiContainerContext containerContext = null;

    private UMOSecurityManager securityManager;

    /**
     * The queue manager to use for component queues and vm connector
     */
    private QueueManager queueManager;

    private UMOWorkManager workManager;

    /**
     * logger used by this class
     */
    private static Log logger = LogFactory.getLog(MuleManager.class);

    /**
     * Default Constructor
     */
    private MuleManager()
    {
        if (config == null)
        {
            config = new MuleConfiguration();
        }
        containerContext = new MultiContainerContext();
        securityManager = new MuleSecurityManager();

        // create the event manager
        notificationManager = new ServerNotificationManager();
        notificationManager.registerEventType(ManagerNotification.class, ManagerNotificationListener.class);
        notificationManager.registerEventType(ModelNotification.class, ModelNotificationListener.class);
        notificationManager.registerEventType(ComponentNotification.class,
            ComponentNotificationListener.class);
        notificationManager.registerEventType(SecurityNotification.class, SecurityNotificationListener.class);
        notificationManager.registerEventType(ManagementNotification.class,
            ManagementNotificationListener.class);
        notificationManager.registerEventType(AdminNotification.class, AdminNotificationListener.class);
        notificationManager.registerEventType(CustomNotification.class, CustomNotificationListener.class);
        notificationManager.registerEventType(ConnectionNotification.class,
            ConnectionNotificationListener.class);
        notificationManager.registerEventType(ExceptionNotification.class,
            ExceptionNotificationListener.class);
        notificationManager.registerEventType(TransactionNotification.class,
            TransactionNotificationListener.class);
    }

    /**
     * Getter method for the current singleton MuleManager
     * 
     * @return the current singleton MuleManager
     */
    public static synchronized UMOManager getInstance()
    {
        if (instance == null)
        {
            logger.info("Creating new MuleManager instance");

            Class clazz = SpiUtils.findService(UMOManager.class, MuleManager.class.getName(),
                MuleManager.class);
            try
            {
                // There should always be a defualt system model registered
                instance = (UMOManager) clazz.newInstance();
                registerSystemModel(config.getSystemModelType());
            }
            catch (Exception e)
            {
                throw new MuleRuntimeException(CoreMessages.failedToCreateManagerInstance(clazz.getName()), e);
            }
        }

        return instance;
    }

    /**
     * A static method to determine if there is an instance of the MuleManager. This
     * should be used instead of <code>
     * if(MuleManager.getInstance()!=null)
     * </code>
     * because getInstance never returns a null. If an istance is not available one
     * is created. This method queries the instance directly.
     * 
     * @return true if the manager is instanciated
     */
    public static synchronized boolean isInstanciated()
    {
        return (instance != null);
    }

    /**
     * Sets the current singleton MuleManager
     * 
     * @deprecated this will go away soon.
     */
    public static synchronized void setInstance(UMOManager manager)
    {
        instance = manager;
        if (instance == null)
        {
            config = new MuleConfiguration();
        }
    }

    /**
     * Gets all statisitcs for this instance
     * 
     * @return all statisitcs for this instance
     */
    public AllStatistics getStatistics()
    {
        return stats;
    }

    /**
     * Sets statistics on this instance
     * 
     * @param stat
     */
    public void setStatistics(AllStatistics stat)
    {
        this.stats = stat;
    }

    /**
     * @return the MuleConfiguration for this MuleManager. This object is immutable
     *         once the manager has initialised.
     */
    public static synchronized MuleConfiguration getConfiguration()
    {
        return config;
    }

    /**
     * Sets the configuration for the <code>MuleManager</code>.
     * 
     * @param config the configuration object
     * @throws IllegalAccessError if the <code>MuleManager</code> has already been
     *             initialised.
     * @deprecated this will go away soon.
     */
    public static synchronized void setConfiguration(MuleConfiguration config) throws UMOException
    {
        if (config == null)
        {
            throw new IllegalArgumentException(CoreMessages.objectIsNull("MuleConfiguration object")
                .getMessage());
        }

        MuleManager.config = config;
        // TODO this call might cause a problem, but the whole setConfiguration()
        // method is doomed anyway
        registerSystemModel(config.getSystemModelType());

    }

    protected static void registerSystemModel(String type) throws UMOException
    {
        if (instance != null)
        {
            // Initialise the system model
            UMOModel model = instance.lookupModel(type);
            if (model != null && model.getComponentNames().hasNext())
            {
                throw new IllegalStateException(
                    "System model is already registered and contains components. Cannot overwrite");
            }
            model = ModelFactory.createModel(config.getSystemModelType());
            model.setName(ModelHelper.SYSTEM_MODEL);
            instance.registerModel(model);
        }
    }

    // Implementation methods
    // -------------------------------------------------------------------------

    /**
     * Destroys the MuleManager and all resources it maintains
     */
    public synchronized void dispose()
    {
        if (disposed.get())
        {
            return;
        }
        try
        {
            if (started.get())
            {
                stop();
            }
        }
        catch (UMOException e)
        {
            logger.error("Failed to stop manager: " + e.getMessage(), e);
        }
        disposed.set(true);
        disposeConnectors();

        for (Iterator i = models.values().iterator(); i.hasNext();)
        {
            UMOModel model = (UMOModel) i.next();
            model.dispose();
        }

        disposeAgents();

        transformers.clear();
        endpoints.clear();
        endpointIdentifiers.clear();
        containerContext.dispose();
        containerContext = null;
        // props.clear();
        fireSystemEvent(new ManagerNotification(this, ManagerNotification.MANAGER_DISPOSED));

        transformers = null;
        endpoints = null;
        endpointIdentifiers = null;
        // props = null;
        initialised.set(false);
        if (notificationManager != null)
        {
            notificationManager.dispose();
        }
        if (workManager != null)
        {
            workManager.dispose();
        }

        if (queueManager != null)
        {
            queueManager.close();
            queueManager = null;
        }

        if ((startDate > 0) && logger.isInfoEnabled())
        {
            logger.info(this.getEndSplash());
        }

        config = new MuleConfiguration();
        instance = null;
    }

    /**
     * Destroys all connectors
     */
    private synchronized void disposeConnectors()
    {
        fireSystemEvent(new ManagerNotification(this, ManagerNotification.MANAGER_DISPOSING_CONNECTORS));
        for (Iterator iterator = connectors.values().iterator(); iterator.hasNext();)
        {
            UMOConnector c = (UMOConnector) iterator.next();
            c.dispose();
        }
        fireSystemEvent(new ManagerNotification(this, ManagerNotification.MANAGER_DISPOSED_CONNECTORS));
    }

    /**
     * {@inheritDoc}
     */
    public Object getProperty(Object key)
    {
        return applicationProps.get(key);
    }

    /**
     * {@inheritDoc}
     */
    public Map getProperties()
    {
        return applicationProps;
    }

    /**
     * {@inheritDoc}
     */
    public TransactionManager getTransactionManager()
    {
        return transactionManager;
    }

    /**
     * {@inheritDoc}
     */
    public UMOConnector lookupConnector(String name)
    {
        return (UMOConnector) connectors.get(name);
    }

    /**
     * {@inheritDoc}
     * 
     * @deprecated endpoint-identifiers have been deprecated in favor of
     *             global-endpoints
     */
    public String lookupEndpointIdentifier(String logicalName, String defaultName)
    {
        String name = (String) endpointIdentifiers.get(logicalName);
        if (name == null)
        {
            return defaultName;
        }
        return name;
    }

    /**
     * {@inheritDoc}
     */
    public UMOEndpoint lookupEndpoint(String logicalName)
    {
        UMOEndpoint endpoint = (UMOEndpoint) endpoints.get(logicalName);
        if (endpoint != null)
        {
            return (UMOEndpoint) endpoint.clone();
        }
        else
        {
            return null;
        }
    }

    /**
     * {@inheritDoc}
     */
    public UMOEndpoint lookupEndpointByAddress(String address)
    {
        UMOEndpoint endpoint = null;
        if (address != null)
        {
            boolean found = false;
            Iterator iterator = endpoints.keySet().iterator();
            while (!found && iterator.hasNext())
            {
                endpoint = (UMOEndpoint) endpoints.get(iterator.next());
                found = (address.equals(endpoint.getEndpointURI().toString()));
            }
        }
        return endpoint;
    }

    /**
     * {@inheritDoc}
     */
    public UMOTransformer lookupTransformer(String name)
    {
        UMOTransformer trans = (UMOTransformer) transformers.get(name);
        if (trans != null)
        {
            try
            {
                return (UMOTransformer) trans.clone();
            }
            catch (Exception e)
            {
                throw new MuleRuntimeException(CoreMessages.failedToClone("Transformer: " + trans.getName()),
                    e);
            }
        }
        return null;
    }

    /**
     * {@inheritDoc}
     */
    public void registerConnector(UMOConnector connector) throws UMOException
    {
        connectors.put(connector.getName(), connector);
        if (initialised.get() || initialising.get())
        {
            connector.initialise();
        }
        if ((started.get() || starting.get()) && !connector.isStarted())
        {
            connector.startConnector();
        }
    }

    /**
     * {@inheritDoc}
     */
    public void unregisterConnector(String connectorName) throws UMOException
    {
        UMOConnector c = (UMOConnector) connectors.remove(connectorName);
        if (c != null)
        {
            c.dispose();
        }
    }

    /**
     * {@inheritDoc}
     * 
     * @deprecated endpoint-identifiers have been deprecated in favor of
     *             global-endpoints
     */
    public void registerEndpointIdentifier(String logicalName, String endpoint)
    {
        endpointIdentifiers.put(logicalName, endpoint);
    }

    /**
     * {@inheritDoc}
     * 
     * @deprecated endpoint-identifiers have been deprecated in favor of
     *             global-endpoints
     */
    public void unregisterEndpointIdentifier(String logicalName)
    {
        endpointIdentifiers.remove(logicalName);
    }

    /**
     * {@inheritDoc}
     */
    public void registerEndpoint(UMOEndpoint endpoint)
    {
        endpoints.put(endpoint.getName(), endpoint);
    }

    /**
     * {@inheritDoc}
     */
    public void unregisterEndpoint(String endpointName)
    {
        UMOEndpoint p = (UMOEndpoint) endpoints.get(endpointName);
        if (p != null)
        {
            endpoints.remove(p);
        }
    }

    /**
     * {@inheritDoc}
     */
    public void registerTransformer(UMOTransformer transformer) throws InitialisationException
    {
        transformer.initialise();
        transformers.put(transformer.getName(), transformer);
        logger.info("Transformer " + transformer.getName() + " has been initialised successfully");
    }

    /**
     * {@inheritDoc}
     */
    public void unregisterTransformer(String transformerName)
    {
        transformers.remove(transformerName);
    }

    /**
     * {@inheritDoc}
     */
    public void setProperty(Object key, Object value)
    {
        applicationProps.put(key, value);
    }

    public void addProperties(Map props)
    {
        applicationProps.putAll(props);
    }

    /**
     * {@inheritDoc}
     */
    public void setTransactionManager(TransactionManager newManager) throws UMOException
    {
        if (transactionManager != null)
        {
            throw new ConfigurationException(CoreMessages.transactionManagerAlreadySet());
        }
        transactionManager = newManager;
    }

    /**
     * {@inheritDoc}
     */
    public synchronized void initialise() throws UMOException
    {
        validateEncoding();
        validateOSEncoding();
        validateXML();

        if (!initialised.get())
        {
            initialising.set(true);
            startDate = System.currentTimeMillis();
            // if no work manager has been set create a default one
            if (workManager == null)
            {
                ThreadingProfile tp = config.getDefaultThreadingProfile();
                logger.debug("Creating default work manager using default threading profile: " + tp);
                workManager = new MuleWorkManager(tp, "UMOManager");
                workManager.start();
            }

            // Start the event manager
            notificationManager.start(workManager);

            // Fire message notifications if the option is set. This will fire
            // inbound and outbound message events that can
            // consume resources in high throughput systems
            if (config.isEnableMessageEvents())
            {
                notificationManager.registerEventType(MessageNotification.class,
                    MessageNotificationListener.class);
            }

            fireSystemEvent(new ManagerNotification(this, ManagerNotification.MANAGER_INITIALISNG));
            if (id == null)
            {
                logger.warn("No unique id has been set on this manager");
            }

            try
            {
                if (securityManager != null)
                {
                    securityManager.initialise();
                }
                if (queueManager == null)
                {
                    try
                    {
                        TransactionalQueueManager queueMgr = new TransactionalQueueManager();
                        QueuePersistenceStrategy ps = getConfiguration().getPersistenceStrategy();
                        queueMgr.setPersistenceStrategy(ps);
                        queueManager = queueMgr;
                    }
                    catch (Exception e)
                    {
                        throw new InitialisationException(CoreMessages.initialisationFailure("QueueManager"),
                            e);
                    }
                }

                initialiseConnectors();
                initialiseEndpoints();
                initialiseAgents();
                for (Iterator i = models.values().iterator(); i.hasNext();)
                {
                    UMOModel model = (UMOModel) i.next();
                    model.initialise();
                }

            }
            finally
            {
                initialised.set(true);
                initialising.set(false);
                fireSystemEvent(new ManagerNotification(this, ManagerNotification.MANAGER_INITIALISED));
            }
        }
    }

    protected void validateEncoding() throws FatalException
    {
        String encoding = System.getProperty(MuleProperties.MULE_ENCODING_SYSTEM_PROPERTY);
        if (encoding == null)
        {
            encoding = config.getEncoding();
            System.setProperty(MuleProperties.MULE_ENCODING_SYSTEM_PROPERTY, encoding);
        }
        else
        {
            config.setEncoding(encoding);
        }
        // Check we have a valid and supported encoding
        if (!Charset.isSupported(config.getEncoding()))
        {
            throw new FatalException(CoreMessages.propertyHasInvalidValue("encoding", config.getEncoding()),
                this);
        }
    }

    protected void validateOSEncoding() throws FatalException
    {
        String encoding = System.getProperty(MuleProperties.MULE_OS_ENCODING_SYSTEM_PROPERTY);
        if (encoding == null)
        {
            encoding = config.getOSEncoding();
            System.setProperty(MuleProperties.MULE_OS_ENCODING_SYSTEM_PROPERTY, encoding);
        }
        else
        {
            config.setOSEncoding(encoding);
        }
        // Check we have a valid and supported encoding
        if (!Charset.isSupported(config.getOSEncoding()))
        {
            throw new FatalException(CoreMessages.propertyHasInvalidValue("osEncoding",
                config.getOSEncoding()), this);
        }
    }

    /**
     * Mule needs a proper JAXP implementation and will complain when run with a plain JDK
     * 1.4. Use the supplied launcher or specify a proper JAXP implementation via
     * <code>-Djava.endorsed.dirs</code>. See the following URLs for more information:
     * <ul>
     * <li> {@link http://xerces.apache.org/xerces2-j/faq-general.html#faq-4}
     * <li> {@link http://xml.apache.org/xalan-j/faq.html#faq-N100D6}
     * <li> {@link http://java.sun.com/j2se/1.4.2/docs/guide/standards/}
     * </ul>
     */
    protected void validateXML() throws FatalException
    {
        SAXParserFactory f = SAXParserFactory.newInstance();
        if (f == null || f.getClass().getName().indexOf("crimson") != -1)
        {
            throw new FatalException(CoreMessages.valueIsInvalidFor(f.getClass().getName(),
                "javax.xml.parsers.SAXParserFactory"), this);
        }
    }

    protected void registerAdminAgent() throws UMOException
    {
        // Allows users to disable all server components and connections
        // this can be useful for testing
        boolean disable = MapUtils.getBooleanValue(System.getProperties(),
            MuleProperties.DISABLE_SERVER_CONNECTIONS_SYSTEM_PROPERTY, false);

        // if endpointUri is blanked out do not setup server components
        if (StringUtils.isBlank(config.getServerUrl()))
        {
            logger.info("Server endpointUri is null, not registering Mule Admin agent");
            disable = true;
        }

        if (disable)
        {
            unregisterAgent(MuleAdminAgent.AGENT_NAME);
        }
        else
        {
            if (lookupAgent(MuleAdminAgent.AGENT_NAME) == null)
            {
                registerAgent(new MuleAdminAgent());
            }
        }
    }

    protected void initialiseEndpoints() throws InitialisationException
    {
        UMOEndpoint ep;
        for (Iterator iterator = this.endpoints.values().iterator(); iterator.hasNext();)
        {
            ep = (UMOEndpoint) iterator.next();
            ep.initialise();
            // the connector has been created for this endpoint so lets
            // set the create connector to 0 so that every time this endpoint
            // is referenced we don't create another connector
            ep.setCreateConnector(0);
        }
    }

    /**
     * Start the <code>MuleManager</code>. This will start the connectors and
     * sessions.
     * 
     * @throws UMOException if the the connectors or components fail to start
     */
    public synchronized void start() throws UMOException
    {
        initialise();

        if (!started.get())
        {
            starting.set(true);
            fireSystemEvent(new ManagerNotification(this, ManagerNotification.MANAGER_STARTING));
            registerAdminAgent();
            if (queueManager != null)
            {
                queueManager.start();
            }
            startConnectors();
            startAgents();
            fireSystemEvent(new ManagerNotification(this, ManagerNotification.MANAGER_STARTING_MODELS));
            for (Iterator i = models.values().iterator(); i.hasNext();)
            {
                UMOModel model = (UMOModel) i.next();
                model.start();
            }
            fireSystemEvent(new ManagerNotification(this, ManagerNotification.MANAGER_STARTED_MODELS));

            started.set(true);
            starting.set(false);
            if (logger.isInfoEnabled())
            {
                logger.info(this.getStartSplash());
            }
            fireSystemEvent(new ManagerNotification(this, ManagerNotification.MANAGER_STARTED));
        }
    }

    /**
     * Start the <code>MuleManager</code>. This will start the connectors and
     * sessions.
     * 
     * @param serverUrl the server Url for this instance
     * @throws UMOException if the the connectors or components fail to start
     */
    public void start(String serverUrl) throws UMOException
    {
        // this.createClientListener = createRequestListener;
        config.setServerUrl(serverUrl);
        start();
    }

    /**
     * Starts the connectors
     * 
     * @throws MuleException if the connectors fail to start
     */
    private void startConnectors() throws UMOException
    {
        for (Iterator iterator = connectors.values().iterator(); iterator.hasNext();)
        {
            UMOConnector c = (UMOConnector) iterator.next();
            c.startConnector();
        }
        logger.info("Connectors have been started successfully");
    }

    private void initialiseConnectors() throws InitialisationException
    {
        for (Iterator iterator = connectors.values().iterator(); iterator.hasNext();)
        {
            UMOConnector c = (UMOConnector) iterator.next();
            c.initialise();
        }
        logger.info("Connectors have been initialised successfully");
    }

    /**
     * Stops the <code>MuleManager</code> which stops all sessions and connectors
     * 
     * @throws UMOException if either any of the sessions or connectors fail to stop
     */
    public synchronized void stop() throws UMOException
    {
        started.set(false);
        stopping.set(true);
        fireSystemEvent(new ManagerNotification(this, ManagerNotification.MANAGER_STOPPING));

        stopConnectors();
        stopAgents();

        if (queueManager != null)
        {
            queueManager.stop();
        }

        logger.debug("Stopping model...");
        fireSystemEvent(new ManagerNotification(this, ManagerNotification.MANAGER_STOPPING_MODELS));
        for (Iterator i = models.values().iterator(); i.hasNext();)
        {
            UMOModel model = (UMOModel) i.next();
            model.stop();
        }
        fireSystemEvent(new ManagerNotification(this, ManagerNotification.MANAGER_STOPPED_MODELS));

        stopping.set(false);
        initialised.set(false);
        fireSystemEvent(new ManagerNotification(this, ManagerNotification.MANAGER_STOPPED));
    }

    /**
     * Stops the connectors
     * 
     * @throws MuleException if any of the connectors fail to stop
     */
    private void stopConnectors() throws UMOException
    {
        logger.debug("Stopping connectors...");
        for (Iterator iterator = connectors.values().iterator(); iterator.hasNext();)
        {
            UMOConnector c = (UMOConnector) iterator.next();
            c.stopConnector();
        }
        logger.info("Connectors have been stopped successfully");
    }

    public UMOModel lookupModel(String name)
    {
        return (UMOModel) models.get(name);
    }

    public void registerModel(UMOModel model) throws UMOException
    {
        models.put(model.getName(), model);
        if (initialised.get())
        {
            model.initialise();
        }

        if (started.get())
        {
            model.start();
        }
    }

    public void unregisterModel(String name)
    {
        UMOModel model = lookupModel(name);
        if (model != null)
        {
            models.remove(model.getName());
            model.dispose();
        }
    }

    public Map getModels()
    {
        return Collections.unmodifiableMap(models);
    }

    /**
     * {@inheritDoc}
     */
    public void registerInterceptorStack(String name, UMOInterceptorStack stack)
    {
        interceptorsMap.put(name, stack);
    }

    /**
     * {@inheritDoc}
     */
    public UMOInterceptorStack lookupInterceptorStack(String name)
    {
        return (UMOInterceptorStack) interceptorsMap.get(name);
    }

    /**
     * {@inheritDoc}
     */
    public Map getConnectors()
    {
        return Collections.unmodifiableMap(connectors);
    }

    /**
     * {@inheritDoc}
     * 
     * @deprecated endpoint-identifiers have been deprecated in favor of
     *             global-endpoints
     */
    public Map getEndpointIdentifiers()
    {
        return Collections.unmodifiableMap(endpointIdentifiers);
    }

    /**
     * {@inheritDoc}
     */
    public Map getEndpoints()
    {
        return Collections.unmodifiableMap(endpoints);
    }

    /**
     * {@inheritDoc}
     */
    public Map getTransformers()
    {
        return Collections.unmodifiableMap(transformers);
    }

    /**
     * {@inheritDoc}
     */
    public boolean isStarted()
    {
        return started.get();
    }

    /**
     * {@inheritDoc}
     */
    public boolean isInitialised()
    {
        return initialised.get();
    }

    /**
     * Determines if the server is currently initialising
     * 
     * @return true if if the server is currently initialising, false otherwise
     */
    public boolean isInitialising()
    {
        return initialising.get();
    }

    /**
     * Determines in the manager is in the process of stopping.
     */
    public boolean isStopping()
    {
        return stopping.get();
    }

    /**
     * {@inheritDoc}
     */
    public long getStartDate()
    {
        return startDate;
    }

    /**
     * Returns a formatted string that is a summary of the configuration of the
     * server. This is the brock of information that gets displayed when the server
     * starts
     * 
     * @return a string summary of the server information
     */
    private String getStartSplash()
    {
        String notset = CoreMessages.notSet().getMessage();

        // Mule Version, Timestamp, and Server ID
        List message = new ArrayList();
        message.add(StringUtils.defaultString(MuleManifest.getProductDescription(), notset));
        message.add(CoreMessages.version().getMessage() + " "
                    + StringUtils.defaultString(MuleManifest.getProductVersion(), notset) + " Build: "
                    + StringUtils.defaultString(MuleManifest.getBuildNumber(), notset));
        message.add(StringUtils.defaultString(MuleManifest.getVendorName(), notset));
        message.add(StringUtils.defaultString(MuleManifest.getProductMoreInfo(), notset));
        message.add(" ");
        message.add(CoreMessages.serverStartedAt(this.getStartDate()));
        message.add("Server ID: " + id);

        // JDK, OS, and Host
        message.add("JDK: " + System.getProperty("java.version") + " (" + System.getProperty("java.vm.info")
                    + ")");
        String patch = System.getProperty("sun.os.patch.level", null);
        message.add("OS: " + System.getProperty("os.name")
                    + (patch != null && !"unknown".equalsIgnoreCase(patch) ? " - " + patch : "") + " ("
                    + System.getProperty("os.version") + ", " + System.getProperty("os.arch") + ")");
        try
        {
            InetAddress host = InetAddress.getLocalHost();
            message.add("Host: " + host.getHostName() + " (" + host.getHostAddress() + ")");
        }
        catch (UnknownHostException e)
        {
            // ignore
        }

        // Mule Agents
        message.add(" ");
        if (agents.size() == 0)
        {
            message.add(CoreMessages.agentsRunning().getMessage() + " " + CoreMessages.none());
        }
        else
        {
            message.add(CoreMessages.agentsRunning());
            UMOAgent umoAgent;
            for (Iterator iterator = agents.values().iterator(); iterator.hasNext();)
            {
                umoAgent = (UMOAgent) iterator.next();
                message.add("  " + umoAgent.getDescription());
            }
        }
        return StringMessageUtils.getBoilerPlate(message, '*', 70);
    }

    private String getEndSplash()
    {
        List message = new ArrayList(2);
        long currentTime = System.currentTimeMillis();
        message.add(CoreMessages.shutdownNormally(new Date()));
        long duration = 10;
        if (startDate > 0)
        {
            duration = currentTime - startDate;
        }
        message.add(CoreMessages.serverWasUpForDuration(duration));

        return StringMessageUtils.getBoilerPlate(message, '*', 78);
    }

    /**
     * {@inheritDoc}
     */
    public void registerAgent(UMOAgent agent) throws UMOException
    {
        agents.put(agent.getName(), agent);
        agent.registered();
        // Don't allow initialisation while the server is being initalised,
        // only when we are done. Otherwise the agent registration
        // order can be corrupted.
        if (initialised.get())
        {
            agent.initialise();
        }
        if ((started.get() || starting.get()))
        {
            agent.start();
        }
    }

    public UMOAgent lookupAgent(String name)
    {
        return (UMOAgent) agents.get(name);
    }

    /**
     * {@inheritDoc}
     */
    public UMOAgent unregisterAgent(String name) throws UMOException
    {
        if (name == null)
        {
            return null;
        }
        UMOAgent agent = (UMOAgent) agents.remove(name);
        if (agent != null)
        {
            agent.dispose();
            agent.unregistered();
        }
        return agent;
    }

    /**
     * Initialises all registered agents
     * 
     * @throws InitialisationException
     */
    protected void initialiseAgents() throws InitialisationException
    {
        logger.info("Initialising agents...");

        // Do not iterate over the map directly, as 'complex' agents
        // may spawn extra agents during initialisation. This will
        // cause a ConcurrentModificationException.
        // Use a cursorable iteration, which supports on-the-fly underlying
        // data structure changes.
        Collection agentsSnapshot = agents.values();
        CursorableLinkedList agentRegistrationQueue = new CursorableLinkedList(agentsSnapshot);
        CursorableLinkedList.Cursor cursor = agentRegistrationQueue.cursor();

        // the actual agent object refs are the same, so we are just
        // providing different views of the same underlying data

        try
        {
            while (cursor.hasNext())
            {
                UMOAgent umoAgent = (UMOAgent) cursor.next();

                int originalSize = agentsSnapshot.size();
                logger.debug("Initialising agent: " + umoAgent.getName());
                umoAgent.initialise();
                // thank you, we are done with you
                cursor.remove();

                // Direct calls to MuleManager.registerAgent() modify the original
                // agents map, re-check if the above agent registered any
                // 'child' agents.
                int newSize = agentsSnapshot.size();
                int delta = newSize - originalSize;
                if (delta > 0)
                {
                    // TODO there's some mess going on in
                    // http://issues.apache.org/jira/browse/COLLECTIONS-219
                    // watch out when upgrading the commons-collections.
                    Collection tail = CollectionUtils.retainAll(agentsSnapshot, agentRegistrationQueue);
                    Collection head = CollectionUtils.subtract(agentsSnapshot, tail);

                    // again, above are only refs, all going back to the original
                    // agents map

                    // re-order the queue
                    agentRegistrationQueue.clear();
                    // 'spawned' agents first
                    agentRegistrationQueue.addAll(head);
                    // and the rest
                    agentRegistrationQueue.addAll(tail);

                    // update agents map with a new order in case we want to
                    // re-initialise
                    // MuleManager on the fly
                    this.agents.clear();
                    for (Iterator it = agentRegistrationQueue.iterator(); it.hasNext();)
                    {
                        UMOAgent theAgent = (UMOAgent) it.next();
                        this.agents.put(theAgent.getName(), theAgent);
                    }
                }
            }
        }
        finally
        {
            // close the cursor as per JavaDoc
            cursor.close();
        }
        logger.info("Agents Successfully Initialised");
    }

    /**
     * {@inheritDoc}
     */
    protected void startAgents() throws UMOException
    {
        UMOAgent umoAgent;
        logger.info("Starting agents...");
        for (Iterator iterator = agents.values().iterator(); iterator.hasNext();)
        {
            umoAgent = (UMOAgent) iterator.next();
            logger.info("Starting agent: " + umoAgent.getDescription());
            umoAgent.start();

        }
        logger.info("Agents Successfully Started");
    }

    /**
     * {@inheritDoc}
     */
    protected void stopAgents() throws UMOException
    {
        logger.info("Stopping agents...");
        for (Iterator iterator = agents.values().iterator(); iterator.hasNext();)
        {
            UMOAgent umoAgent = (UMOAgent) iterator.next();
            logger.debug("Stopping agent: " + umoAgent.getName());
            umoAgent.stop();
        }
        logger.info("Agents Successfully Stopped");
    }

    /**
     * {@inheritDoc}
     */
    protected void disposeAgents()
    {
        UMOAgent umoAgent;
        logger.info("disposing agents...");
        for (Iterator iterator = agents.values().iterator(); iterator.hasNext();)
        {
            umoAgent = (UMOAgent) iterator.next();
            logger.debug("Disposing agent: " + umoAgent.getName());
            umoAgent.dispose();
        }
        logger.info("Agents Successfully Disposed");
    }

    /**
     * associates a Dependency Injector container or Jndi container with Mule. This
     * can be used to integrate container managed resources with Mule resources
     * 
     * @param container a Container context to use. By default, there is a default
     *            Mule container <code>MuleContainerContext</code> that will assume
     *            that the reference key for an oblect is a classname and will try to
     *            instanciate it.
     */
    public void setContainerContext(UMOContainerContext container) throws UMOException
    {
        if (container == null)
        {
            if (containerContext != null)
            {
                containerContext.dispose();
            }
            containerContext = new MultiContainerContext();
        }
        else
        {
            container.initialise();
            containerContext.addContainer(container);
        }
    }

    /**
     * associates a Dependency Injector container with Mule. This can be used to
     * integrate container managed resources with Mule resources
     * 
     * @return the container associated with the Manager
     */
    public UMOContainerContext getContainerContext()
    {
        return containerContext;
    }

    /**
     * {@inheritDoc}
     */
    public void registerListener(UMOServerNotificationListener l) throws NotificationException
    {
        registerListener(l, null);
    }

    public void registerListener(UMOServerNotificationListener l, String resourceIdentifier)
        throws NotificationException
    {
        if (notificationManager == null)
        {
            throw new NotificationException(CoreMessages.serverEventManagerNotEnabled());
        }
        notificationManager.registerListener(l, resourceIdentifier);
    }

    /**
     * {@inheritDoc}
     */
    public void unregisterListener(UMOServerNotificationListener l)
    {
        if (notificationManager != null)
        {
            notificationManager.unregisterListener(l);
        }
    }

    /**
     * Fires a mule 'system' event. These are notifications that are fired because
     * something within the Mule instance happened such as the Model started or the
     * server is being disposed.
     * 
     * @param e the event that occurred
     */
    protected void fireSystemEvent(UMOServerNotification e)
    {
        if (notificationManager != null)
        {
            notificationManager.fireEvent(e);
        }
        else if (logger.isDebugEnabled())
        {
            logger.debug("Event Manager is not enabled, ignoring event: " + e);
        }
    }

    /**
     * Fires a server notification to all registered
     * {@link org.mule.impl.internal.notifications.CustomNotificationListener}
     * notificationManager. TODO RM: This method now duplicates #fireSystemEvent()
     * completely
     * 
     * @param notification the notification to fire. This must be of type
     *            {@link org.mule.impl.internal.notifications.CustomNotification}
     *            otherwise an exception will be thrown.
     * @throws UnsupportedOperationException if the notification fired is not a
     *             {@link org.mule.impl.internal.notifications.CustomNotification}
     */
    public void fireNotification(UMOServerNotification notification)
    {
        // if(notification instanceof CustomNotification) {
        if (notificationManager != null)
        {
            notificationManager.fireEvent(notification);
        }
        else if (logger.isDebugEnabled())
        {
            logger.debug("Event Manager is not enabled, ignoring notification: " + notification);
        }
        // } else {
        // throw new UnsupportedOperationException(new
        // Message(Messages.ONLY_CUSTOM_EVENTS_CAN_BE_FIRED).getMessage());
        // }
    }

    public void setId(String id)
    {
        this.id = id;
    }

    public String getId()
    {
        return id;
    }

    /**
     * Sets the security manager used by this Mule instance to authenticate and
     * authorise incoming and outgoing event traffic and service invocations
     * 
     * @param securityManager the security manager used by this Mule instance to
     *            authenticate and authorise incoming and outgoing event traffic and
     *            service invocations
     */
    public void setSecurityManager(UMOSecurityManager securityManager) throws InitialisationException
    {
        this.securityManager = securityManager;
        if (securityManager != null && isInitialised())
        {
            this.securityManager.initialise();
        }
    }

    /**
     * Gets the security manager used by this Mule instance to authenticate and
     * authorise incoming and outgoing event traffic and service invocations
     * 
     * @return he security manager used by this Mule instance to authenticate and
     *         authorise incoming and outgoing event traffic and service invocations
     */
    public UMOSecurityManager getSecurityManager()
    {
        return securityManager;
    }

    /**
     * Obtains a workManager instance that can be used to schedule work in a thread
     * pool. This will be used primarially by UMOAgents wanting to schedule work.
     * This work Manager must <b>never</b> be used by provider implementations as
     * they have their own workManager accessible on the connector. If a workManager
     * has not been set by the time the <code>initialise()</code> method has been
     * called a default <code>MuleWorkManager</code> will be created using the
     * <i>DefaultThreadingProfile</i> on the <code>MuleConfiguration</code>
     * object.
     * 
     * @return a workManager instance used by the current MuleManager
     * @see org.mule.config.ThreadingProfile
     * @see MuleConfiguration
     */
    public UMOWorkManager getWorkManager()
    {
        return workManager;
    }

    /**
     * Obtains a workManager instance that can be used to schedule work in a thread
     * pool. This will be used primarially by UMOAgents wanting to schedule work.
     * This work Manager must <b>never</b> be used by provider implementations as
     * they have their own workManager accible on the connector. If a workManager has
     * not been set by the time the <code>initialise()</code> method has been
     * called a default <code>MuleWorkManager</code> will be created using the
     * <i>DefaultThreadingProfile</i> on the <code>MuleConfiguration</code>
     * object.
     * 
     * @param workManager the workManager instance used by the current MuleManager
     * @throws IllegalStateException if the workManager has already been set.
     * @see org.mule.config.ThreadingProfile
     * @see MuleConfiguration
     * @see MuleWorkManager
     */
    public void setWorkManager(UMOWorkManager workManager)
    {
        if (this.workManager != null)
        {
            throw new IllegalStateException(CoreMessages.cannotSetObjectOnceItHasBeenSet("workManager")
                .getMessage());
        }
        this.workManager = workManager;
    }

    public QueueManager getQueueManager()
    {
        return queueManager;
    }

    public void setQueueManager(QueueManager queueManager)
    {
        this.queueManager = queueManager;
    }
}
