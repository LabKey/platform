/*
 * $Id: LifecycleInterceptor.java 7963 2007-08-21 08:53:15Z dirk.olmes $
 * --------------------------------------------------------------------------------------
 * Copyright (c) MuleSource, Inc.  All rights reserved.  http://www.mulesource.com
 *
 * The software in this package is published under the terms of the CPAL v1.0
 * license, a copy of which has been included with this distribution in the
 * LICENSE.txt file.
 */

package org.mule.interceptors;

import org.mule.umo.UMOInterceptor;
import org.mule.umo.lifecycle.Disposable;
import org.mule.umo.lifecycle.Initialisable;

/**
 * <code>LifecycleInterceptor</code> is a UMOInterceptor interface with two additional
 * lifecycle methods provided by <code>Initialisable</code> and <code>Disposable</code>.
 */
public interface LifecycleInterceptor extends UMOInterceptor, Initialisable, Disposable
{
    // no methods
}
