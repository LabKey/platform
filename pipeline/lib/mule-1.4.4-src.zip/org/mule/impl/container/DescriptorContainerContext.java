/*
 * $Id: DescriptorContainerContext.java 7963 2007-08-21 08:53:15Z dirk.olmes $
 * --------------------------------------------------------------------------------------
 * Copyright (c) MuleSource, Inc.  All rights reserved.  http://www.mulesource.com
 *
 * The software in this package is published under the terms of the CPAL v1.0
 * license, a copy of which has been included with this distribution in the
 * LICENSE.txt file.
 */

package org.mule.impl.container;

import org.mule.config.i18n.CoreMessages;
import org.mule.impl.model.ModelHelper;
import org.mule.umo.UMODescriptor;
import org.mule.umo.manager.ContainerException;
import org.mule.umo.manager.ObjectNotFoundException;

import java.io.Reader;

/**
 * Will load the component from the descriptors' own properties.
 */
public class DescriptorContainerContext extends AbstractContainerContext
{
    public static final String DESCRIPTOR_CONTAINER_NAME = "descriptor";

    public DescriptorContainerContext()
    {
        super(DESCRIPTOR_CONTAINER_NAME);
    }

    public void configure(Reader configuration) throws ContainerException
    {
        throw new UnsupportedOperationException("configure");
    }

    public void setName(String name)
    {
        // no op
    }

    /**
     * Queries a component from the underlying container
     * 
     * @param key the key fo find the component with. Its up to the individual
     *            implementation to check the type of this key and look up objects
     *            accordingly
     * @return The component found in the container
     * @throws org.mule.umo.manager.ObjectNotFoundException if the component is not
     *             found
     */
    public Object getComponent(Object key) throws ObjectNotFoundException
    {

        if (key instanceof DescriptorContainerKeyPair)
        {
            DescriptorContainerKeyPair dckp = (DescriptorContainerKeyPair) key;

            UMODescriptor d = ModelHelper.getDescriptor(dckp.getDescriptorName());
            if (d == null)
            {
                throw new ObjectNotFoundException(
                    key.toString(), 
                    new ContainerException(
                        CoreMessages.failedToLoad("descriptor: " + dckp.getDescriptorName())));
            }
            Object component = d.getProperties().get(dckp.getKey());
            if (component == null)
            {
                throw new ObjectNotFoundException(dckp.getKey().toString());
            }
            return component;
        }
        else
        {
            throw new ObjectNotFoundException(key.toString());
        }
    }

}
